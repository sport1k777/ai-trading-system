class CHOCHAnalyzer:

    @staticmethod
    def analyze(df):

        if len(df) < 30:
            return "NO_CHOCH"

        highs = []
        lows = []

        for i in range(2, len(df) - 2):

            high = df.iloc[i]["high"]

            if (
                high > df.iloc[i - 1]["high"]
                and high > df.iloc[i - 2]["high"]
                and high > df.iloc[i + 1]["high"]
                and high > df.iloc[i + 2]["high"]
            ):
                highs.append((i, high))

            low = df.iloc[i]["low"]

            if (
                low < df.iloc[i - 1]["low"]
                and low < df.iloc[i - 2]["low"]
                and low < df.iloc[i + 1]["low"]
                and low < df.iloc[i + 2]["low"]
            ):
                lows.append((i, low))

        if len(highs) < 2 or len(lows) < 2:
            return "NO_CHOCH"

        last_high = highs[-1][1]
        prev_high = highs[-2][1]

        last_low = lows[-1][1]
        prev_low = lows[-2][1]

        close = df.iloc[-1]["close"]

        if close > prev_high:
            return "BULLISH_CHOCH"

        if close < prev_low:
            return "BEARISH_CHOCH"

        return "NO_CHOCH"


if __name__ == "__main__":

    from app.collectors.candles import CandleCollector

    collector = CandleCollector()

    df = collector.get_candles()

    print("\n========== CHOCH ==========\n")

    print(CHOCHAnalyzer.analyze(df))