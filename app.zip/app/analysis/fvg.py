class FVGAnalyzer:

    @staticmethod
    def analyze(df):

        if len(df) < 5:
            return None

        gaps = []

        for i in range(2, len(df)):

            c1 = df.iloc[i - 2]
            c2 = df.iloc[i - 1]
            c3 = df.iloc[i]

            # Bullish FVG
            if c1["high"] < c3["low"]:
                gaps.append({
                    "type": "BULLISH",
                    "top": c3["low"],
                    "bottom": c1["high"],
                    "index": i
                })

            # Bearish FVG
            elif c1["low"] > c3["high"]:
                gaps.append({
                    "type": "BEARISH",
                    "top": c1["low"],
                    "bottom": c3["high"],
                    "index": i
                })

        if not gaps:
            return None

        return gaps[-1]


if __name__ == "__main__":

    from app.collectors.candles import CandleCollector

    collector = CandleCollector()

    df = collector.get_candles()

    gap = FVGAnalyzer.analyze(df)

    print("\n========== FVG ==========\n")

    print(gap)