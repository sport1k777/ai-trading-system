class LiquidityAnalyzer:

    @staticmethod
    def analyze(df):

        last = df.iloc[-1]

        high = last["high"]
        low = last["low"]

        prev_high = df["high"].iloc[-21:-1].max()
        prev_low = df["low"].iloc[-21:-1].min()

        if high > prev_high:
            return {
                "type": "BUY_SIDE",
                "level": prev_high
            }

        if low < prev_low:
            return {
                "type": "SELL_SIDE",
                "level": prev_low
            }

        return None


if __name__ == "__main__":

    from app.collectors.candles import CandleCollector

    collector = CandleCollector()

    df = collector.get_candles()

    liquidity = LiquidityAnalyzer.analyze(df)

    print("\n========== LIQUIDITY ==========\n")

    print(liquidity)