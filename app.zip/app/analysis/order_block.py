class OrderBlockAnalyzer:

    @staticmethod
    def analyze(df):

        if len(df) < 10:
            return None

        bullish = None
        bearish = None

        for i in range(len(df) - 10, len(df)):

            candle = df.iloc[i]

            if candle["close"] > candle["open"]:
                bullish = {
                    "type": "BULLISH",
                    "high": float(candle["high"]),
                    "low": float(candle["low"]),
                    "index": i
                }

            elif candle["close"] < candle["open"]:
                bearish = {
                    "type": "BEARISH",
                    "high": float(candle["high"]),
                    "low": float(candle["low"]),
                    "index": i
                }

        return {
            "bullish": bullish,
            "bearish": bearish
        }


if __name__ == "__main__":

    from app.collectors.candles import CandleCollector

    collector = CandleCollector()

    df = collector.get_candles()

    blocks = OrderBlockAnalyzer.analyze(df)

    print("\n========== ORDER BLOCK ==========\n")

    print(blocks)